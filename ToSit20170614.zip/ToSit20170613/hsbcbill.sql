grant select on hsbcbill.customer_sign_info to hsbcebank;
alter table hsbcbill.tbl_swt_draft_info add ENDORSE_CNT varchar2(4) default '0';

UPDATE hsbcbill.TBL_SWT_DRAFT_INFO draftinfo
   SET ENDORSE_CNT =
       (select COUNT(id)
          from hsbcbill.Tbl_Swt_Draft_Log draftlog
         where draftinfo.electric_Draft_Id = draftlog.electric_Draft_Id
           and draftlog.msg_Type = '03')
 WHERE draftinfo.ENDORSE_CNT = '0';
 
 
create table GROUP_CUSTOMER_INFO
(
  ID                            INTEGER not null,
  CUST_NO                       VARCHAR2(20),
  CUST_NAME                     VARCHAR2(180),
  CUST_ADDRESS                  VARCHAR2(180),
  GROUP_FLAG                    CHAR(1),
  GROUP_CUST_NO                 VARCHAR2(20),
  ORGAN_CODE                    VARCHAR2(24),
  LAST_UPD_OPER_ID              INTEGER,
  LAST_UPD_TIME                 CHAR(14),
  RSV1                          VARCHAR2(60),
  RSV2                          VARCHAR2(60),
  RSV3                          VARCHAR2(60),
  RSV4                          VARCHAR2(60),
  RSV5                          VARCHAR2(60),
  RSV6                          VARCHAR2(60),
  RSV7                          VARCHAR2(60),
  RSV8                          VARCHAR2(60),
  RSV9                          VARCHAR2(60),
  RSV10                         VARCHAR2(60),
  constraint IDX_GROUP_CUSTOMER_INFO_ID primary key (ID) using index
);
create sequence SEQ_GROUP_CUSTOMER_INFO
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

insert into hsbcbill.function_info values(69,149,'���ſͻ���Ϣά��','/fpages/customer/ftl/CustomerGroupInfo.ftl',2,0,14,8);

grant select,insert,delete,update on hsbcbill.tbl_swt_draft_info to hsbcebank;

grant select on hsbcbill.tbl_swt_business_log to hsbcebank;

grant select on hsbcbill.tbl_swt_draft_log to hsbcebank;

--alter table hsbcbill.tbl_swt_batch_dtl add COST_ACCOUNT VARCHAR2(32) ;--�����˺�
--alter table hsbcbill.tbl_swt_batch_dtl add ACCT_TRADE_ACCOUNT VARCHAR2(32) ;--ó���˺�

grant select on hsbcbill.group_customer_info to hsbcebank;
grant select on hsbcbill.Tbl_Swt_Main_Txnlog to hsbcebank;
