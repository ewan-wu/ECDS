create synonym hsbcebank.customer_sign_info for hsbcbill.customer_sign_info;
--create synonym hsbcebank.tbl_swt_draft_info for hsbcbill.tbl_swt_draft_info;

insert into hsbcebank.tbl_eb_data_dic (ID, DATA_TYPE_NO, DATA_NO, DATA_TYPE_NAME, DATA_NO_LEN, DATA_NAME, LIMIT_FLAG, HIGH_LIMIT, LOW_LIMIT, EFFECT_DATE, EXPIRE_DATE, TIMESTAMPS, MISCFLGS)
values (1018, 150, 'A01                 ', 'BUSSLOG����״̬', 3, '01-��¼��', '0', '0                   ', '0                   ', null, null, null, null);

insert into hsbcebank.tbl_eb_data_dic (ID, DATA_TYPE_NO, DATA_NO, DATA_TYPE_NAME, DATA_NO_LEN, DATA_NAME, LIMIT_FLAG, HIGH_LIMIT, LOW_LIMIT, EFFECT_DATE, EXPIRE_DATE, TIMESTAMPS, MISCFLGS)
values (1019, 150, 'A02                 ', 'BUSSLOG����״̬', 3, '02-�ѷ���', '0', '0                   ', '0                   ', null, null, null, null);

insert into hsbcebank.tbl_eb_data_dic (ID, DATA_TYPE_NO, DATA_NO, DATA_TYPE_NAME, DATA_NO_LEN, DATA_NAME, LIMIT_FLAG, HIGH_LIMIT, LOW_LIMIT, EFFECT_DATE, EXPIRE_DATE, TIMESTAMPS, MISCFLGS)
values (1020, 150, 'A03                 ', 'BUSSLOG����״̬', 3, '03-��ȷ�ϳɹ�', '0', '0                   ', '0                   ', null, null, null, null);

insert into hsbcebank.tbl_eb_data_dic (ID, DATA_TYPE_NO, DATA_NO, DATA_TYPE_NAME, DATA_NO_LEN, DATA_NAME, LIMIT_FLAG, HIGH_LIMIT, LOW_LIMIT, EFFECT_DATE, EXPIRE_DATE, TIMESTAMPS, MISCFLGS)
values (1021, 150, 'A04                 ', 'BUSSLOG����״̬', 3, '04-��ȷ��ʧ��', '0', '0                   ', '0                   ', null, null, null, null);

insert into hsbcebank.tbl_eb_data_dic (ID, DATA_TYPE_NO, DATA_NO, DATA_TYPE_NAME, DATA_NO_LEN, DATA_NAME, LIMIT_FLAG, HIGH_LIMIT, LOW_LIMIT, EFFECT_DATE, EXPIRE_DATE, TIMESTAMPS, MISCFLGS)
values (1022, 150, 'A05                 ', 'BUSSLOG����״̬', 3, '05-��ǩ��', '0', '0                   ', '0                   ', null, null, null, null);

insert into hsbcebank.tbl_eb_data_dic (ID, DATA_TYPE_NO, DATA_NO, DATA_TYPE_NAME, DATA_NO_LEN, DATA_NAME, LIMIT_FLAG, HIGH_LIMIT, LOW_LIMIT, EFFECT_DATE, EXPIRE_DATE, TIMESTAMPS, MISCFLGS)
values (1023, 150, 'A06                 ', 'BUSSLOG����״̬', 3, '06-�Ѿܾ�', '0', '0                   ', '0                   ', null, null, null, null);

insert into hsbcebank.tbl_eb_data_dic (ID, DATA_TYPE_NO, DATA_NO, DATA_TYPE_NAME, DATA_NO_LEN, DATA_NAME, LIMIT_FLAG, HIGH_LIMIT, LOW_LIMIT, EFFECT_DATE, EXPIRE_DATE, TIMESTAMPS, MISCFLGS)
values (1024, 150, 'A07                 ', 'BUSSLOG����״̬', 3, '07-������', '0', '0                   ', '0                   ', null, null, null, null);

insert into hsbcebank.tbl_eb_data_dic (ID, DATA_TYPE_NO, DATA_NO, DATA_TYPE_NAME, DATA_NO_LEN, DATA_NAME, LIMIT_FLAG, HIGH_LIMIT, LOW_LIMIT, EFFECT_DATE, EXPIRE_DATE, TIMESTAMPS, MISCFLGS)
values (1025, 150, 'A08                 ', 'BUSSLOG����״̬', 3, '08-������ʧ��', '0', '0                   ', '0                   ', null, null, null, null);

insert into hsbcebank.tbl_eb_data_dic (ID, DATA_TYPE_NO, DATA_NO, DATA_TYPE_NAME, DATA_NO_LEN, DATA_NAME, LIMIT_FLAG, HIGH_LIMIT, LOW_LIMIT, EFFECT_DATE, EXPIRE_DATE, TIMESTAMPS, MISCFLGS)
values (1026, 150, 'B01                 ', 'BUSSLOG����״̬', 3, '01-δǩ��', '0', '0                   ', '0                   ', null, null, null, null);

insert into hsbcebank.tbl_eb_data_dic (ID, DATA_TYPE_NO, DATA_NO, DATA_TYPE_NAME, DATA_NO_LEN, DATA_NAME, LIMIT_FLAG, HIGH_LIMIT, LOW_LIMIT, EFFECT_DATE, EXPIRE_DATE, TIMESTAMPS, MISCFLGS)
values (1027, 150, 'B02                 ', 'BUSSLOG����״̬', 3, '02-��ǩ��', '0', '0                   ', '0                   ', null, null, null, null);

insert into hsbcebank.tbl_eb_data_dic (ID, DATA_TYPE_NO, DATA_NO, DATA_TYPE_NAME, DATA_NO_LEN, DATA_NAME, LIMIT_FLAG, HIGH_LIMIT, LOW_LIMIT, EFFECT_DATE, EXPIRE_DATE, TIMESTAMPS, MISCFLGS)
values (1028, 150, 'B03                 ', 'BUSSLOG����״̬', 3, '03-�Ѿܾ�', '0', '0                   ', '0                   ', null, null, null, null);

insert into hsbcebank.tbl_eb_data_dic (ID, DATA_TYPE_NO, DATA_NO, DATA_TYPE_NAME, DATA_NO_LEN, DATA_NAME, LIMIT_FLAG, HIGH_LIMIT, LOW_LIMIT, EFFECT_DATE, EXPIRE_DATE, TIMESTAMPS, MISCFLGS)
values (1029, 150, 'B04                 ', 'BUSSLOG����״̬', 3, '04-ǩ����ȷ��', '0', '0                   ', '0                   ', null, null, null, null);

insert into hsbcebank.tbl_eb_data_dic (ID, DATA_TYPE_NO, DATA_NO, DATA_TYPE_NAME, DATA_NO_LEN, DATA_NAME, LIMIT_FLAG, HIGH_LIMIT, LOW_LIMIT, EFFECT_DATE, EXPIRE_DATE, TIMESTAMPS, MISCFLGS)
values (1030, 150, 'B05                 ', 'BUSSLOG����״̬', 3, '05-������ȷ��', '0', '0                   ', '0                   ', null, null, null, null);

insert into hsbcebank.tbl_eb_data_dic (ID, DATA_TYPE_NO, DATA_NO, DATA_TYPE_NAME, DATA_NO_LEN, DATA_NAME, LIMIT_FLAG, HIGH_LIMIT, LOW_LIMIT, EFFECT_DATE, EXPIRE_DATE, TIMESTAMPS, MISCFLGS)
values (1031, 150, 'B06                 ', 'BUSSLOG����״̬', 3, '06-������', '0', '0                   ', '0                   ', null, null, null, null);

insert into hsbcebank.tbl_eb_data_dic (ID, DATA_TYPE_NO, DATA_NO, DATA_TYPE_NAME, DATA_NO_LEN, DATA_NAME, LIMIT_FLAG, HIGH_LIMIT, LOW_LIMIT, EFFECT_DATE, EXPIRE_DATE, TIMESTAMPS, MISCFLGS)
values (1032, 150, 'B07                 ', 'BUSSLOG����״̬', 3, '07-����ʧ��', '0', '0                   ', '0                   ', null, null, null, null);

insert into hsbcebank.tbl_eb_data_dic (ID, DATA_TYPE_NO, DATA_NO, DATA_TYPE_NAME, DATA_NO_LEN, DATA_NAME, LIMIT_FLAG, HIGH_LIMIT, LOW_LIMIT, EFFECT_DATE, EXPIRE_DATE, TIMESTAMPS, MISCFLGS)
values (1033, 150, 'B08                 ', 'BUSSLOG����״̬', 3, '08-���ʧ��', '0', '0                   ', '0                   ', null, null, null, null);

create synonym hsbcebank.tbl_swt_business_log for hsbcbill.tbl_swt_business_log;
create synonym hsbcebank.tbl_swt_draft_log for hsbcbill.tbl_swt_draft_log;

insert into hsbcebank.tbl_eb_data_dic (ID, DATA_TYPE_NO, DATA_NO, DATA_TYPE_NAME, DATA_NO_LEN, DATA_NAME, LIMIT_FLAG, HIGH_LIMIT, LOW_LIMIT, EFFECT_DATE, EXPIRE_DATE, TIMESTAMPS, MISCFLGS)
values (100020, 404, '25                  ', '��������', 4, '��Ʊ�Ǽ�-һ��������', '0', '0                   ', '0                   ', null, null, null, null);

insert into hsbcebank.tbl_eb_data_dic (ID, DATA_TYPE_NO, DATA_NO, DATA_TYPE_NAME, DATA_NO_LEN, DATA_NAME, LIMIT_FLAG, HIGH_LIMIT, LOW_LIMIT, EFFECT_DATE, EXPIRE_DATE, TIMESTAMPS, MISCFLGS)
values (100021, 404, '26                  ', '��������', 4, '��Ʊ�Ǽ�-һ��������', '0', '0                   ', '0                   ', null, null, null, null);

create synonym hsbcebank.group_customer_info for hsbcbill.group_customer_info;

insert into hsbcebank.tbl_eb_data_dic (ID, DATA_TYPE_NO, DATA_NO, DATA_TYPE_NAME, DATA_NO_LEN, DATA_NAME, LIMIT_FLAG, HIGH_LIMIT, LOW_LIMIT, EFFECT_DATE, EXPIRE_DATE, TIMESTAMPS, MISCFLGS)
values (100022, 317, '00                  ', '��ѯ��Χ', 2, '���Ź�˾', '0', '0                   ', '0                   ', null, null, null, null);


insert into hsbcebank.tbl_eb_function_info (ID, FUNCID, FUNCNAME, PAGEPATH, LOCATION, ISDIRECTORY, LASTDIRECTORY, SHOWSEQ)
values (80, 75, '���ſͻ�ҵ���ѯ', null, 1, 1, 0, 9);

insert into hsbcebank.tbl_eb_function_info (ID, FUNCID, FUNCNAME, PAGEPATH, LOCATION, ISDIRECTORY, LASTDIRECTORY, SHOWSEQ)
values (83, 7503, '���ſͻ�Ʊ�ݲ�ѯҵ��', '/fpages/ebank/ftl/groupcustquery/ebankGroupCustomerDraftActorsQuery.ftl', 1, 0, 75, 3);

insert into hsbcebank.tbl_eb_function_info (ID, FUNCID, FUNCNAME, PAGEPATH, LOCATION, ISDIRECTORY, LASTDIRECTORY, SHOWSEQ)
values (82, 7502, '���ſͻ���ʷҵ���ѯ', '/fpages/ebank/ftl/groupcustquery/ebankGroupCustomerCommonHisBusQuery.ftl?_msgType=', 1, 0, 75, 2);

insert into hsbcebank.tbl_eb_function_info (ID, FUNCID, FUNCNAME, PAGEPATH, LOCATION, ISDIRECTORY, LASTDIRECTORY, SHOWSEQ)
values (81, 7501, '���ſͻ���ǰҵ���ѯ', '/fpages/ebank/ftl/groupcustquery/ebankGroupCustomerCommonBusQuery.ftl', 1, 0, 75, 1);

insert into hsbcebank.tbl_eb_function_info (ID, FUNCID, FUNCNAME, PAGEPATH, LOCATION, ISDIRECTORY, LASTDIRECTORY, SHOWSEQ)
values (85, 7505, '���ſͻ��Զ���������Ϣ��ѯ', '/fpages/ebank/ftl/groupcustquery/GroupCustomerAutoTransactionQuery.ftl', 1, 0, 75, 5);

insert into hsbcebank.tbl_eb_function_info (ID, FUNCID, FUNCNAME, PAGEPATH, LOCATION, ISDIRECTORY, LASTDIRECTORY, SHOWSEQ)
values (84, 7504, '���ſͻ�Ʊ����ʷ��Ϣ��ѯ', '/fpages/ebank/ftl/groupcustquery/ebankGroupActorQueryMain.ftl', 1, 0, 75, 4);
create synonym hsbcebank.Tbl_Swt_Main_Txnlog for hsbcbill.Tbl_Swt_Main_Txnlog;